import requests
import json
from . import ME3
from datetime import datetime


class ShopifyAPI:
    def __init__(self, configs: dict):
        if not configs:
            raise ValueError("未提供shopify配置")
        # 配置key 名称遵循平台传参约定：'shopify_url' 和 'shopify_accessToken'
        self.url = configs.get("shopify_url")
        self.accessToken = configs.get("shopify_accessToken")
        if not self.url:
            raise ValueError("配置中未定义shopify的url！")
        if not self.accessToken:
            raise ValueError("配置中未定义shopify的accessToken！")
        self.headers = {"Content-Type": "application/json", "X-Shopify-Access-Token": self.accessToken}

    def get_product_info(self, sku):
        try:
            query = f"""
            {{
                productVariants(first: 1, query: "sku:{sku}") {{
                    edges {{
                        node {{
                            id
                            sku
                            inventoryQuantity
                            inventoryItem {{
                                id
                                inventoryLevels(first: 1) {{
                                    edges {{
                                        node {{
                                            id
                                            available
                                        }}
                                    }}
                                }}
                            }}
                        }}
                    }}
                }}
            }}
            """
            response = requests.post(self.url, headers=self.headers, data=json.dumps({"query": query}), verify=False)
            response.raise_for_status()
            return True, response.json()
        except Exception as e:
            err_msg = f"{type(e).__name__}：{e}"
            log_msg = f"请求shopify商品信息遇到异常：{err_msg}"
            return False, log_msg

    def update_inventory(self, inventory_levels_id, current_quantity, new_quantity):
        try:
            update_query = f"""
            mutation {{
                inventoryAdjustQuantity(input: {{
                    inventoryLevelId: \"{inventory_levels_id}\",
                    availableDelta: {new_quantity - current_quantity}
                }}) {{
                    inventoryLevel {{
                        id
                        available
                    }}
                }}
            }}
            """
            update_response = requests.post(self.url, headers=self.headers, data=json.dumps({"query": update_query}), verify=False)
            update_response.raise_for_status()
            return True, update_response.json()
        except Exception as e:
            err_msg = f"{type(e).__name__}：{e}"
            log_msg = f"更新shopify更新商品库存异常： {err_msg}"
            return False, log_msg

    def batch_get_product_info(self, batchOfSKUsMap):
        try:
            queries = []
            for i, (sku, quantity) in enumerate(batchOfSKUsMap.items()):
                alias = f"variant{i}"
                queries.append(
                    f"""
                    {alias}: productVariants(first: 1, query: "sku:{sku}") {{
                        edges {{
                            node {{
                                id
                                sku
                                inventoryQuantity
                                inventoryItem {{
                                    id
                                    inventoryLevels(first: 1) {{
                                        edges {{
                                            node {{
                                                id
                                                available
                                            }}
                                        }}
                                    }}
                                }}
                            }}
                        }}
                    }}
                """
                )
            query = f'{{{"".join(queries)}}}'
            response = requests.post(self.url, headers=self.headers, data=json.dumps({"query": query}), verify=False)
            response.raise_for_status()
            return True, response.json()
        except Exception as e:
            err_msg = f"{type(e).__name__}：{e}"
            log_msg = f"请求shopify商品信息遇到异常：{err_msg}"
            return False, log_msg

    def batch_update_product_quantity_by_sku(self, batchOfSKUsMap):
        status, product_result = self.batch_get_product_info(batchOfSKUsMap)
        logInfoList = []
        if not status:
            return status, product_result
        if product_result and product_result.get("data"):
            try:
                for variant_key, variant_data in product_result['data'].items():
                    if variant_data['edges']:
                        node = variant_data['edges'][0]['node']
                        sku = node['sku']
                        inventory_item = node['inventoryItem']
                        if inventory_item and inventory_item['inventoryLevels']['edges']:
                            inventory_levels_id = inventory_item['inventoryLevels']['edges'][0]['node']['id']
                            current_quantity = inventory_item['inventoryLevels']['edges'][0]['node']['available']
                            new_quantity = batchOfSKUsMap.get(sku)
                            if new_quantity is None:
                                logInfoList.append(f"{sku}：未在待更新列表中，跳过")
                                continue
                            if (current_quantity != new_quantity):
                                status, update_result = self.update_inventory(inventory_levels_id, current_quantity, new_quantity)
                                if not status:
                                    return status, update_result
                                if isinstance(update_result, dict) and "errors" in update_result:
                                    logInfoList.append(f"{sku}：更新库存遇到异常：{update_result['errors'][0]['message']}")
                                else:
                                    logInfoList.append(f"{sku}：更新成功；更新前数量：{current_quantity}，更新后数量：{new_quantity}")
                            else:
                                logInfoList.append(f"{sku}：无需更新，库存数量未变动：{current_quantity}")
                return True, logInfoList
            except IndexError:
                return False, "商品数据不完整或不存在库存信息"
        else:
            return False, "未找到匹配的商品信息"

    def get_ME3_inventory_info(self, url, sku, store_code, key, secret):
        request_params = {
            "pageNo": "1",
            "pageSize": "5",
            "startModifiedTime": "1970-01-01 00:00:01",
            "endModifiedTime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "barcode": sku,
            "store_code": store_code,
        }
        request_params_string = ME3.assembly_request_body("stock.goods_sscx", key, secret, request_params)
        import urllib.parse
        encoded_params = urllib.parse.urlencode(request_params_string)
        full_url = f"{url}&{encoded_params}"
        try:
            response = requests.get(full_url, verify=False)
        except Exception as e:
            err_msg = f"{type(e).__name__}：{e}"
            log_msg = f"查询ME3库存信息异常： {err_msg}"
            return False, log_msg, None
        ME3_result = json.loads(response.text)
        if "status" in ME3_result and ME3_result["status"] == 1:
            if not ('data' in ME3_result and 'data' in ME3_result["data"]):
                log_msg = f"ME3店铺{store_code}中没有{sku}的商品数据；请求地址：\n\t\t{full_url}"
                return False, log_msg, None
            shop_stock = ME3_result["data"]["data"]
            if len(shop_stock) != 0:
                quantity = shop_stock[0]["num"]
                return True, f"成功", quantity
            else:
                return False, f"没有有效商品数据", None
        else:
            msg = ME3_result.get("message")
            return False, f"请求ME3获取商品库存失败，ME3消息：{msg}", None