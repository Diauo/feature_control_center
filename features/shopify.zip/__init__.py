__meta__ = {
    "name": "Shopify库存同步",
    "description": "执行Shopify库存同步",
    "customer": "GREY.ECHO.UNIT",
    "configs": {
        "ME3_url": (None, "ME3网店库存获取地址"),
        "ME3_app_key": (None, "ME3分配的授权key"),
        "ME3_secret": (None, "ME3分配的授权秘钥"),
        "shopify_url": (None, "shopify graphql 地址"),
        "shopify_accessToken": (None, "shopify 应用访问令牌"),
        "batchLenght": (100, "每批次更新的SKU数量"),
    }
}

import os
import traceback
import time
import pandas as pd
from app.util.feature_execution_context import FeatureExecutionContext
from .shopify import ShopifyAPI


def run(configs: dict, ctx: FeatureExecutionContext):
    """
    模块主执行入口，遵循 platform 的 `run(configs, ctx)` 规范
    :param configs: 配置字典（由平台注入）
    :param ctx: 执行上下文，用于日志和状态上报
    :return: (bool, str, dict)
    """
    # 校验必要配置
    url = configs.get("ME3_url")
    key = configs.get("ME3_app_key")
    secret = configs.get("ME3_secret")
    shopify_url = configs.get("shopify_url")
    shopify_token = configs.get("shopify_accessToken")
    batchLenght = int(configs.get("batchLenght")) or 100

    if not url or not key or not secret:
        msg = "配置中未定义 ME3 的相关配置（ME3_url/app_key/secret）！"
        ctx.error(msg)
        return False, msg, None
    if not shopify_url or not shopify_token:
        msg = "配置中未定义 shopify 的相关配置（shopify_url/shopify_accessToken）！"
        ctx.error(msg)
        return False, msg, None

    ctx.log("开始执行shopify库存同步")

    # 初始化 ShopifyAPI
    shopify_api = ShopifyAPI({
        "shopify_url": shopify_url,
        "shopify_accessToken": shopify_token,
    })

    # 读取同步控制数据源
    need_sync_sku = {}
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_source_file_path = os.path.join(current_dir, 'dataSource.xlsx')

    if not os.path.exists(data_source_file_path):
        log_msg = f"未找到同步控制数据源文件：{data_source_file_path}"
        ctx.error(log_msg)
        return False, log_msg, None

    try:
        itemData = pd.read_excel(data_source_file_path, header=0, dtype={"sku": str, "store_code": str})
        for row in itemData.itertuples(index=False):
            if not row.sku:
                ctx.log("没有读取到有效的sku，跳过")
                continue
            if not row.store_code:
                ctx.log("没有读取到有效的仓库代码，跳过")
                continue
            need_sync_sku[str(row.sku).strip()] = str(row.store_code).strip()
    except Exception as e:
        tb = traceback.format_exc()
        msg = f"读取数据源文件失败：{e}\n{tb}"
        ctx.error(msg)
        return False, msg, None

    # 批量更新逻辑
    batchOfSKUsMap = {}
    updated_count_dict = {}

    try:
        for me3_sku, store_codes in need_sync_sku.items():
            total_ME3_inventory = 0
            for store_code in store_codes.split(','):
                status, message, qty = shopify_api.get_ME3_inventory_info(url, me3_sku, store_code, key, secret)
                if not status:
                    ctx.error(f"{me3_sku}：{message}")
                    # 遇到ME3失败时跳过该仓库但继续尝试其他仓库
                    continue
                total_ME3_inventory += int(qty)

            batchOfSKUsMap[me3_sku] = total_ME3_inventory
            updated_count_dict[me3_sku] = total_ME3_inventory

            if len(batchOfSKUsMap) >= batchLenght:
                status, result = shopify_api.batch_update_product_quantity_by_sku(batchOfSKUsMap)
                if not status:
                    ctx.error(f"批量更新失败：{result}")
                else:
                    for log_msg in result:
                        ctx.log(log_msg)
                batchOfSKUsMap = {}

        # 处理剩余的小批量
        if len(batchOfSKUsMap) > 0:
            status, result = shopify_api.batch_update_product_quantity_by_sku(batchOfSKUsMap)
            if not status:
                ctx.error(f"批量更新失败：{result}")
            else:
                for log_msg in result:
                    ctx.log(log_msg)

    except Exception as e:
        tb = traceback.format_exc()
        log_msg = f"同步失败：{type(e).__name__}：{e}\n{tb}"
        ctx.error(log_msg)
        return False, log_msg, None

    ctx.log("shopify库存同步执行完成")
    return True, "shopify库存同步执行完成", None
